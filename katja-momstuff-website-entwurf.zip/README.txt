KATJA.MOMSTUFF WEBSITE – ENTWURF

Dateien:
- index.html
- impressum.html
- datenschutz.html
- styles.css

Die Website ist absichtlich ohne externe Fonts, Analytics, Tracking-Pixel, eingebettete Social-Media-Feeds oder andere Marketing-Skripte aufgebaut.

VOR VERÖFFENTLICHUNG:
1. Tatsächliche Website-Plattform/Hosting festlegen.
2. Impressum mit WKO-Impressumsservice abgleichen.
3. Datenschutzerklärung anhand des konkreten Hosters/der Plattform und aller tatsächlich eingesetzten Dienste finalisieren.
4. Echte Instagram-/TikTok-URLs einsetzen.
5. Eigene Fotos/Logo ergänzen, falls gewünscht.
